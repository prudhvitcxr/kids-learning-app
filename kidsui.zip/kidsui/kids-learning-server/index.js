require('dotenv').config(); // Load environment variables from .env file
const express = require('express'); // Import Express framework
const cors = require('cors'); // Import CORS middleware
const OpenAI = require('openai'); // Import OpenAI API client

const app = express(); // Create an Express application
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // Parse JSON request bodies

// Set up OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY // Use API key from environment variables
});

// Health check route
app.get('/', (req, res) => {
  res.send('Kids Learning Server is running...'); // Respond with a simple message
});

// Explanation route
app.post('/api/explain', async (req, res) => {
  console.log('Received request:', req.body); // Log the incoming request
  try {
    const { topic, style } = req.body; // Destructure topic and style from request body
    const prompt = `
      You are a friendly children's teacher. Explain the following topic in a way that reflects the style: ${style}.
      Topic: ${topic}
      Explanation:
    `; // Construct the prompt for OpenAI

    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Use the appropriate model for chat completions
      messages: [
        { role: 'system', content: 'You are a friendly teacher for kids.' },
        { role: 'user', content: prompt },
      ],
      max_tokens: 200,
      temperature: 0.7,
    });

    const generatedText = response.choices[0].message.content.trim(); // Access the generated explanation
    console.log('OpenAI API Response:', response.data); // Log the OpenAI response
    res.status(200).json({ explanation: generatedText }); // Send the explanation back to the client
  } catch (error) {
    console.error('Error with OpenAI API:', error); // Log the error details
    res.status(500).json({ error: 'An error occurred while generating explanation.' }); // Send error response
  }
});

const PORT = process.env.PORT || 4000; // Set the port from environment variable or default to 4000
app.listen(PORT, () => {
  console.log(`Kids Learning Server listening on port ${PORT}`); // Start the server and log the port
});
