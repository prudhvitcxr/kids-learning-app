import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [topic, setTopic] = useState('');
  const [style, setStyle] = useState('Physics');
  const [customStyle, setCustomStyle] = useState('');
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);

  const handleExplain = async () => {
    try {
      setLoading(true);
      setExplanation('');

      // If the user filled the "Custom Style" field, use that instead
      const selectedStyle = customStyle.trim() ? customStyle : style;

      const response = await axios.post('http://localhost:4000/api/explain', {
        topic,
        style: selectedStyle,
      });

      setExplanation(response.data.explanation);
    } catch (error) {
      console.error('Error fetching explanation:', error);
      setExplanation('Oops! Something went wrong. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <h1>Kids Learning App</h1>
      <p>Ask any topic or question, and pick a style!</p>

      <div className="input-area">
        <input
          type="text"
          placeholder="Enter a topic or question..."
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
        />
      </div>

      <h3>Select a style or provide a custom style below:</h3>

      <div className="style-buttons">
        <label>
          <input
            type="radio"
            name="style"
            value="Physics"
            checked={style === 'Physics' && !customStyle}
            onChange={(e) => {
              setStyle(e.target.value);
              setCustomStyle('');
            }}
          />
          Physics
        </label>

        <label>
          <input
            type="radio"
            name="style"
            value="Math"
            checked={style === 'Math' && !customStyle}
            onChange={(e) => {
              setStyle(e.target.value);
              setCustomStyle('');
            }}
          />
          Mathematics
        </label>

        <label>
          <input
            type="radio"
            name="style"
            value="Finance"
            checked={style === 'Finance' && !customStyle}
            onChange={(e) => {
              setStyle(e.target.value);
              setCustomStyle('');
            }}
          />
          Finance
        </label>

        <label>
          <input
            type="radio"
            name="style"
            value="Sports"
            checked={style === 'Sports' && !customStyle}
            onChange={(e) => {
              setStyle(e.target.value);
              setCustomStyle('');
            }}
          />
          Sports
        </label>
      </div>

      <div className="custom-style-area">
        <label htmlFor="customStyle">
          Or type a custom style to explain the topic (e.g., "Explain like a pirate"):
        </label>
        <input
          type="text"
          name="customStyle"
          placeholder="Explain it like a pirate..."
          value={customStyle}
          onChange={(e) => setCustomStyle(e.target.value)}
        />
      </div>

      <button className="explain-btn" onClick={handleExplain} disabled={!topic || loading}>
        {loading ? 'Explaining...' : 'Explain Topic'}
      </button>

      <div className="explanation-area">
        <h3>Explanation:</h3>
        {loading ? <p>Please wait, generating answer...</p> : <p>{explanation}</p>}
      </div>
    </div>
  );
}

export default App;
